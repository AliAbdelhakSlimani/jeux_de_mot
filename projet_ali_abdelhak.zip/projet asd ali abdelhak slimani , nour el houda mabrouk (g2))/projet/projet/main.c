#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
void transform(char ligne[]){
    for(int i=0;i<=strlen(ligne)-1;i++){
       if(ligne[i]!='-' && ligne[i]!='�' && ligne[i]!='�' &&ligne[i]!='�' && ligne[i]!='�' &&ligne[i]!='�' && ligne[i]!='�' && ligne[i]!='�' &&ligne[i]!='�' &&ligne[i]!='�' &&ligne[i]!='�' && ligne[i]!='�' && ligne[i]!='�' && ligne[i]!='�' && ligne[i]!='�' && ligne[i]!='�' && ligne[i]!='�'){
            ligne[i]=toupper(ligne[i]);
        }
        if(ligne[i]=='�' || ligne[i]=='�' || ligne[i]=='�'){
            ligne[i]='A';
        }
        else{
            if(ligne[i]=='�' || ligne[i]=='�' || ligne[i]=='�' || ligne[i]=='�'){
                ligne[i]='E';
            }
            else{
                if(ligne[i]=='�' || ligne[i]=='�' ){
                    ligne[i]='I';
                }

                else{
                    if(ligne[i]=='�' || ligne[i]=='�'){
                        ligne[i]='O';
                    }
                    else{
                       if(ligne[i]=='�' || ligne[i]=='�' || ligne[i]=='�'){
                           ligne[i]='U';
                       }
                        else{
                            if(ligne[i]=='�'){
                                ligne[i]='Y';
                            }
                            else{
                                if(ligne[i]=='�'){
                                   ligne[i]='C';
                                }
                            }
                        }
                    }

                }
            }
        }
    }
}
void remplissage_mat_fich(char mat[336531][30]){
    FILE *F;
    F=fopen("dictionnaire.txt","r");
    char ligne[30];
    int k=0;
    while(fgets(ligne,30,F)!=NULL){
        transform(ligne);
        for(int i=0;i<strlen(ligne)-1;i++){
            mat[k][i]=ligne[i];
        }
        k++;
    }
}
int teste(char ligne[],char liste[],int nb_lettre){
    int i=0;
    int j,trouve=0,find;
    while(i<=strlen(ligne)-1 && trouve==0){
        find=1;
        j=1;
            while(j<=nb_lettre && find==1){
                if(ligne[i]==liste[j]){
                    find=0;

                }
                j++;
            }
        if(j>nb_lettre){
            trouve=1;
        }
        i++;
    }
    return trouve;
}
int maxim(char combinaison_max [1000][30],char combinaison[1000][30],int l ,int l1){
    int maximum=strlen(combinaison[0]);
    for(int i=0;i<=l-1;i++){
        if(strlen(combinaison[i])>maximum){
            maximum=strlen(combinaison[i]);
        }
    }
    l1=0;
    for(int i=0;i<=l-1;i++){
        if(strlen(combinaison[i])==maximum){
            for(int j=0;j<=strlen(combinaison[i])-1;j++){
                combinaison_max[l1][j]=combinaison[i][j];
            }
            l1++;
        }
    }
    return l1;
}
int saisie_choix(int choix){
    printf("si tu veux jouer a un      tapez 1 \n");
    printf("si tu veux jouez a un sous une contrainte de temps      tapez 2 \n");
    printf("si tu veux jouez a deux      tapez 3\n");
    printf("si tu veux quitter      tapez 0\n");
    printf("\n\n                                          ");
    do{

            printf("\n                                          ");
            printf("\n                                 donnez votre choix : ");
            scanf("%d",&choix);
            if(choix!=1 && choix!=2 && choix!=3 && choix!=0){
                system("powershell -c (New-Object Media.SoundPlayer 'reponse_fausse.wav').PlaySync();");
            }
            getchar();
    }while(choix!=1 && choix!=2 && choix!=3 && choix!=0);
    return choix;
}
int saisie_du_nbre_des_lettres(int nb_lettre){
    printf("\033[0;36mDonnez la taille qui est entre [7,8,9] du mot le plus long a retrouver : \033[0m");
    scanf("%d",&nb_lettre);
    while(nb_lettre!=7 && nb_lettre!=8 && nb_lettre!=9) {
        system("powershell -c (New-Object Media.SoundPlayer 'reponse_fausse.wav').PlaySync();");
        printf("\n    ");
        printf("\033[0;31mla taille que vous avez saisi n'est pas dans [7,8,9] \033[0m\n");
        printf("\033[0;36mTapez la Taille qui est compris entre [7,8,9]  du mot le plus long a retrouver : \033[0m");
        scanf("%d",&nb_lettre);
        getchar();
    }
    return nb_lettre;
    }
void aleatoire(int nb_lettre, char liste[10]){
    char cv;
    char lettre;
    int i,al;
    srand(time(NULL ));
    char voyelle[]={'E','O','Y','I','A','U'};

    for(i=1;i<=nb_lettre;i++){
        do{
            fflush(stdin);
            printf("caractere %d ",i);
            printf("\033[0;31m(tapez c/C pour generer une consonne ou tapez v/V pour generer une voyelle) : \033[0m");
            scanf("%c",&cv);
            getchar();
            if((toupper(cv)!='C' && toupper(cv)!='V')){
                system("powershell -c (New-Object Media.SoundPlayer 'reponse_fausse.wav').PlaySync();");
            }
            fflush(stdin);
        }while((toupper(cv)!='C' && toupper(cv)!='V'));
        if(toupper(cv)=='C' ){
            do{
                al=(rand()%26)+65;
                lettre=(char)al;
            }while(lettre=='E' || lettre=='O' || lettre=='Y' || lettre=='I' || lettre=='A' || lettre=='U');
            liste[i]=lettre;
            }
        else {
            al=rand()%6;
            lettre=voyelle[al];
            liste[i]=lettre;
        }

    }
    printf("Devinez puis saisissez le plus long mot qui est cach� dans la liste.\n {");
    for(i=1;i<=nb_lettre;i++){
        printf("\033[0;36m %c        \033[0m",liste[i]);
    } printf ("}\n");

}
int remplir(char mat[336531][30],char liste[],int nb_lettre,char combinaison[300][30],int l) {
    int compt;
    l=0;
    for(int i=0;i<336531;i++){
        if(teste(mat[i],liste,nb_lettre)==0){
            for(compt=0;compt<=strlen(mat[i])-1;compt++){
                combinaison[l][compt]=mat[i][compt];
            }
            combinaison[l][compt]='\0';
            l++;
        }
    }
    return l;
}
int lawwej_max(char chaine_fourni[30], char combinaison_max[1000][30],int l1){
    int trouve=1;
    int i=0;
    while(trouve==1 && i<l1){
        int l9it=0;
        if(strlen(chaine_fourni)==strlen(combinaison_max[i])){
            int k=0;
            while(l9it==0 && k<strlen(chaine_fourni)){
                if(chaine_fourni[k]!=combinaison_max[i][k]){
                    l9it=1;
                }
                k++;
            }
            if(l9it==0){
            trouve=0;
            }
        }//eya assal denya
        i++;
    }
    return trouve;
}
int nb_lettre_a_deux(int nb_lettre){
    printf("      \ndonnez la taille du plus long mot a retrouver \n");
    printf("        soyez conscient et entrez une nombre qui ne d�passe pas 26 et sup�rieur a 1 et pair \n");
    printf("nombre des lettres : ");
    scanf("%d",&nb_lettre);
    while(nb_lettre%2!=0 || nb_lettre>26 || nb_lettre<2){
        system("powershell -c (New-Object Media.SoundPlayer 'reponse_fausse.wav').PlaySync();");
        printf("donnez un entier qui ne d�passe pas 26 et pair . soyez prudent : ");
        scanf("%d",&nb_lettre);
        getchar();
    }
    return nb_lettre;
}
int cherche_max_mat(char mat[336531][30],char combinaison_max_adeux[10000][30],int nb_lettre,int l2){
    l2=0;
    for(int i=0;i<336531;i++){
        if(strlen(mat[i])==nb_lettre){
            for(int j=0;j<nb_lettre;j++){
                combinaison_max_adeux[l2][j]=mat[i][j];
            }
            printf("%s\n",combinaison_max_adeux[l2]);
            l2++;
        }
    }
    return 0;
}

int cherche(char chaine[],char chaine_manche[27][30],int i,int compt,int pas){
    int test=1;
    while(test==1 && i<compt){
        int verif=0;
        int j=0;
        if(strlen(chaine)==strlen(chaine_manche[i])){
            while(verif==0 && j<strlen(chaine)){
                if(chaine[j]!=chaine_manche[i][j]){
                    verif=1;
                }
                j++;
            }
        }
        if(j>=strlen(chaine)){
            test=0;
        }
        i=i+pas;
    }
    return test;
}
                                                                //programme principale

int main(){
    system("powershell -c (New-Object Media.SoundPlayer 'bienvenue.wav').PlaySync();");
   int choix,nb_lettre;
    printf("\033[0;33m                                                J E U   D E   M O T S\n\033[0m");
    //remplissage du fichier dans le matrice
    static char mat[336531][30];
    remplissage_mat_fich(mat);
    //saisie du choix
    do{
        choix=saisie_choix(choix);
        if(choix==1){
            system("cls");
            nb_lettre=saisie_du_nbre_des_lettres(nb_lettre);
            //production de la liste des lettres par l'ordinateur
            char liste[10];
            aleatoire(nb_lettre,liste);
            //Recherche tous le combinaisons possibles de la liste des lettres fournies par l'ordinateur
            char combinaison[1000][30];
            char combinaison_max[1000][30];
            int l,l1;
            l=remplir(mat,liste,nb_lettre,combinaison,l);
            l1=maxim(combinaison_max,combinaison,l,l1);
            int tcherchi=1,tal9a=1;
            int rep=1;
            char chaine_fourni[30];
            int maxi=0;
            while(tal9a==1 && rep<=nb_lettre){
                fflush(stdin);
                printf("chaine %d \033[0;33m(donnez une chaine des lettres qu'elle peut etre generee de la liste)  : \033[0m", rep);
                scanf("%s",chaine_fourni);
                transform(chaine_fourni);
                if(lawwej_max(chaine_fourni,combinaison_max,l1)==0){
                    printf("\033[0;33mBravo ! , Le mot que vous avez saisi est le plus long mot dans la liste \033[0m\n\n\n\n");
                    system("powershell -c (New-Object Media.SoundPlayer 'bravo.wav').PlaySync();");
                    tal9a=0;
                }
                else{
                    if(lawwej_max(chaine_fourni,combinaison,l)==0){
                        if(strlen(chaine_fourni)>maxi){
                        maxi=strlen(chaine_fourni);
                        }
                        tcherchi=0;
                        printf("\033[0;32mla chaine que vous avez saisi est correct mais n'est pas le plus long mot\033[0m\n\n");
                    }
                    else{
                        system("powershell -c (New-Object Media.SoundPlayer 'reponse_fausse.wav').PlaySync();");
                        printf("\nla chaine que vous saisi est incorrect\n");
                        printf("\033[0;31m              NB:la chaine valide c'est une chaine qui est compos� par les lettres de la liste\033[0m\n\n");
                    }
                }
                rep++;
            }
            if(tal9a==1 && tcherchi==0){printf("\033[0;36mpuisque vous n'avait pas devinait qu'elle est la plus long mot dans la liste donc votre score est %d \n\033[0m",maxi);}
            if(tcherchi==1){printf("\033[0;31maucun des mots que vous avez saisis existe dans le dictionnaire �crire des mots valides svp\n\033[0m");}
            printf("tapez 1 pour afficher le(s) plus long mot(s) qui peuvent apparaitre de la liste\n\n");
            printf("tapez 2 pour afficher tous les combinaison possible de la liste\n");
            int choix_affichage;
            do{
                printf("\n                     votre choix est :");
                scanf("%d",&choix_affichage);
                getchar();
                fflush(stdin);
                if(choix_affichage!=2 && choix_affichage!=1){
                        system("powershell -c (New-Object Media.SoundPlayer 'reponse_fausse.wav').PlaySync();");
                }
            }while(choix_affichage!=2 && choix_affichage!=1);
            if(choix_affichage==1){
                printf("la liste des plus long mot(s) possible(s) est :\n");
                for(int i=0;i<l1;i++){
                    printf("\033[0;35m              -%s\033[0m\n",combinaison_max[i]);
                }
            }
            else{
                if(choix_affichage==2){
                    printf("la liste des mots possibles est :\n");

                    for(int i=0;i<l;i++){
                        printf("\033[0;35m              -%s\033[0m\n",combinaison[i]);
                    }
                }
            }
        }
        else{
            if(choix==2){
                system("cls");
                clock_t debut,fin,test_deb,test_fin;
                double diff_tentative,diff=0;
                float add_se=0;
                nb_lettre=saisie_du_nbre_des_lettres(nb_lettre);
                //production de la liste des lettres par l'ordinateur
                char liste[10];
                aleatoire(nb_lettre,liste);
                //Recherche tous le combinaisons possibles de la liste des lettres fournies par l'ordinateur
                char combinaison[1000][30];
                char combinaison_max[1000][30];
                int l,l1;
                l=remplir(mat,liste,nb_lettre,combinaison,l);
                l1=maxim(combinaison_max,combinaison,l,l1);
                int tcherchi=0,tal9a=1;
                int rep=1;
                char chaine_fourni[30];
                int maxi=0;
                debut =clock();
                while(tal9a==1 && rep<=nb_lettre && diff<(nb_lettre*nb_lettre)){
                    fflush(stdin);
                    test_deb=clock();
                    printf("chaine %d \033[0;34m(donnez une chaine des lettres qu'elle peut etre fourni de la liste ): \033[0m",rep);
                    scanf("%s",chaine_fourni);
                    fin=clock();
                    diff_tentative=((double)(fin-test_deb))/CLOCKS_PER_SEC;
                    diff=(((double)(fin-debut))/CLOCKS_PER_SEC)+add_se;
                    transform(chaine_fourni);
                    if(lawwej_max(chaine_fourni,combinaison_max,l1)==0){
                            if(diff<=(nb_lettre*nb_lettre)){
                                printf("\033[0;33mBravo ! , Le mot que vous avez saisi est le plus long mot dans la liste\033[0m\n");//d�finir une couleur jaune
                                system("powershell -c (New-Object Media.SoundPlayer 'bravo.wav').PlaySync();");
                                tal9a=0;
                            }
                            else{
                                if(diff>(nb_lettre*nb_lettre)){
                                    printf("\033[0;33mce mot est le plus long mais\033[0m\n \n");//d�finir une couleur jaune
                                    printf("\033[0;31mvous avez depassee la limite qui est %d sec\033[0m\n\n\n\n",(nb_lettre*nb_lettre));//d�finir une couleur rouge
                                }
                            }

                    }

                    else{

                        if(lawwej_max(chaine_fourni,combinaison,l)==0){
                            if(diff<=(nb_lettre*nb_lettre)){
                                if(strlen(chaine_fourni)>maxi){
                                    maxi=strlen(chaine_fourni);
                                }
                                tcherchi=0;
                                printf("\033[0;33mla chaine que vous avez saisi est correct mais n'est pas le plus long mot\033[0m\n\n\n");
                                if(diff_tentative>nb_lettre){
                                    printf("\033[0;33mvous etes maintenant dans la tentative num %d \033[0m\n\n\n\n\n",(int)diff/(nb_lettre)+1);
                                }
                                else{
                                    printf("\033[0;33mbravo ! , vous n'avait pas depasser les %d secondes de la tentatives n %d\033[0m\n\n\n\n",nb_lettre,(int)diff/(nb_lettre)+1);
                                }
                            }
                            else{
                                printf("le mots que vous avez saisi est correct \033[0;31mmais vous avez depassee la limite qui est %d secondes\033[0m\n\n\n",(nb_lettre*nb_lettre));
                            }
                    }
                    else{
                        if(diff<=(nb_lettre*nb_lettre)){
                            printf("\033[0;31mla chaine que vous saisi est incorrect\033[0m\n");
                            printf("\033[0;31m              NB:la chaine valide c'est une chaine qui est compose par les lettres de la liste\033[0m\n\n");
                            system("powershell -c (New-Object Media.SoundPlayer 'reponse_fausse.wav').PlaySync();");
                            if(diff_tentative>7){
                                    printf("\033[0;33mvous etes maintenant dans la tentative num %d\033[0m\n\n\n\n\n",(int)diff/(nb_lettre)+1);
                                }
                                else{
                                    printf("\033[0;31mvous n'avait pas d�passer les %d secondes de la tentatives n %d  mais malheureusement le mot est incorrecte \033[0m\n\n\n\n",nb_lettre,(int)diff/(nb_lettre)+1);
                                }
                        }
                        else{
                            printf("\033[0;31mvotre chaine est incorrecte et en plus vous avez depassee la limite de temps qui est %dsec\033[0m\n\n\n" ,(nb_lettre*nb_lettre));
                            system("powershell -c (New-Object Media.SoundPlayer 'reponse_fausse.wav').PlaySync();");
                        }
                    }
                    }
                    if(diff_tentative<nb_lettre){
                        add_se=nb_lettre-diff_tentative;
                    }
                    else{
                        add_se=0;
                    }
                    rep++;
                }
                if(tal9a==1 && tcherchi==0){printf(" \n\n\n\033[0;36m-----puisque vous n'avait pas devinait qu'elle est la plus long mot dans la liste donc votre score est %d------\n\033[0m",maxi);}
                if(tcherchi==1){printf("\033[0;31maucun des mots que vous avez saisis existe dans le dictionnaire ecrire des mots valides svp \033[0m\n");}
                printf("tapez 1 pour afficher le(s) plus long mot(s) qui peuvent apparaitre de la liste\n");
                printf("tapez 2 pour afficher tous les combinaison possible de la liste\n");
                int choix_affichage;
                do{
                    printf("\n                     votre choix est :");
                    scanf("%d",&choix_affichage);
                    getchar();
                    fflush(stdin);
                    if(choix_affichage!=2 && choix_affichage!=1){
                            system("powershell -c (New-Object Media.SoundPlayer 'reponse_fausse.wav').PlaySync();");
                    }
                }while(choix_affichage!=2 && choix_affichage!=1);
                if(choix_affichage==1){
                printf("la liste des plus long mot(s) possible(s) est :\n");
                for(int i=0;i<l1;i++){
                    printf("\033[0;35m              -%s\033[0m\n",combinaison_max[i]);
                }
            }
            else{
                if(choix_affichage==2){
                    printf("la liste des mots possibles est :\n");

                    for(int i=0;i<l;i++){
                        printf("\033[0;35m              -%s\033[0m\n",combinaison[i]);
                    }
                }
            }
        }
            if(choix==3){
                system("cls");
                int l,l1,nb_manche=1;
                char choix;
                int manche[10000][2];
                do{
                    printf("\033[35m----------------------la manche n�%d se commence---------------\033[0m\n",nb_manche);
                    fflush(stdin);
                    nb_lettre=nb_lettre_a_deux(nb_lettre);
                    char liste[10];
                    aleatoire(nb_lettre,liste);
                    char combinaison[1000][30];
                    char combinaison_max[1000][30];
                    l=remplir(mat,liste,nb_lettre,combinaison,l);
                    printf("------------------------------------\n");
                    l1=maxim(combinaison_max,combinaison,l,l1);
                    int score1=0,score2=0, compt=0;
                    int trouve=1;
                    int num_joueur=1,j=0;
                    char chaine_manche[nb_lettre][30];
                    while(trouve!=3 && compt<nb_lettre){
                            printf("joueur n %d : ",num_joueur);
                            scanf("%s",chaine_manche[compt]);
                            transform(chaine_manche[compt]);
                            if(lawwej_max(chaine_manche[compt],combinaison_max,l1)==0 ){
                                if(cherche(chaine_manche[compt],chaine_manche,0,compt,2)==1){
                                    trouve=trouve+1;
                                    printf("\033[33mbravo joueur n�%d vous avez devine(e) le plus long mot dans la liste des lettres\033[0m\n",num_joueur);
                                    system("powershell -c (New-Object Media.SoundPlayer 'bravo.wav').PlaySync();");
                                    if(num_joueur==1){
                                        score1=strlen(chaine_manche[compt]);
                                    }
                                    else{
                                        score2=strlen(chaine_manche[compt]);
                                    }
                                }
                                if(cherche(chaine_manche[compt],chaine_manche,0,compt,2)==0){
                                    printf("\033[31mle joueur N 2 a entre(e) le meme mot que le joueur 1\033[0m\n",num_joueur);
                                    system("powershell -c (New-Object Media.SoundPlayer 'mot_entree.wav').PlaySync();");
                                    for(int k=0;k<strlen(chaine_manche[compt]);k++){
                                        chaine_manche[compt][k]='\0';
                                    }
                                }
                            }
                            else{
                                if(cherche(chaine_manche[compt],chaine_manche,0,compt,1)==1){
                                    if(lawwej_max(chaine_manche[compt],combinaison,l)==0){
                                        printf("\033[32mbien , cette chaine est correcte mais n'est ps la plus long\033[0m\n");
                                        if(strlen(chaine_manche[compt])>score1 && num_joueur==1){
                                            score1=strlen(chaine_manche[compt]);
                                        }
                                        if(strlen(chaine_manche[compt])>score2 && num_joueur==2){
                                            score2=strlen(chaine_manche[compt]);
                                        }
                                    }
                                }
                                else{
                                    if(cherche(chaine_manche[compt],chaine_manche,num_joueur-1,compt,2)==0){
                                        printf("\033[31mvous avez declaree cette mots precedament\033[0m\n");
                                        system("powershell -c (New-Object Media.SoundPlayer 'mot_entree.wav').PlaySync();");
                                        for(int k=0;k<strlen(chaine_manche[compt]);k++){
                                            chaine_manche[compt][k]='\0';
                                        }
                                    }
                                    else{
                                        if(cherche(chaine_manche[compt],chaine_manche,0,compt,1)==0){
                                            printf("\033[31ml'autre joueur a d�claree cette mot , svp d�claree une autre mot valide\033[0m\n");
                                            system("powershell -c (New-Object Media.SoundPlayer 'mot_entree.wav').PlaySync();");
                                            for(int k=0;k<strlen(chaine_manche[compt]);k++){
                                                chaine_manche[compt][k]='\0';
                                            }
                                        }
                                        else{
                                            printf("\033[31mmots incorrecte svp saisisez une mot valide form�e par les lettres de la liste\033[0m\n");
                                            system("powershell -c (New-Object Media.SoundPlayer 'reponse_fausse.wav').PlaySync();");
                                        }
                                    }
                                }
                            }
                            if(compt>=2 &&  trouve==2){
                                trouve++;
                            }
                            if(num_joueur==1){
                                num_joueur++;
                            }
                            else{
                                num_joueur--;
                                if(trouve==2){
                                    trouve++;
                                }
                            }
                            compt++;
                    }
                    manche[nb_manche-1][0]=score1;
                    manche[nb_manche-1][1]=score2;
                    if(score1>score2){
                        printf("\033[33m----------------------le joueur n1 a romporte cette manche\033[0m\n\n\n");
                    }
                    else{
                        if(score2>score1){
                            printf("\033[33m----------------------le joueur n2 a remporte cette manche\033[0m\n\n\n");
                        }
                        if(score1==score2){
                            printf("\033[33m----------------------egalite\033[0m\n\n\n");
                        }
                    }
                    printf("---------------------------------------------------------\n");
                    int i=0;
                    while(i<compt){
                        if(lawwej_max(chaine_manche[i],combinaison,l)==0){
                            printf("%s(%d)\n",chaine_manche[i] , strlen(chaine_manche[i]));
                        }
                        i=i+2;
                    }
                    printf("\n\033[35m                             le score de le joueur 1 est %d\033[0m\n\n",score1);
                    printf("----------------------------------------------------------\n");
                    i=1;
                    while(i<compt){
                       if(lawwej_max(chaine_manche[i],combinaison,l)==0){
                            printf("%s(%d)\n",chaine_manche[i] , strlen(chaine_manche[i]));
                        }
                        i=i+2;
                    }
                    printf("\n\033[35m                             le score de le joueur 2 est %d\033[0m\n\n",score2);
                    printf("tapez 1 pour afficher le(s) plus long mot(s) qui peuvent apparaitre de la liste\n");
                    printf("tapez 2 pour afficher tous les combinaison possible de la liste\n");
                    int choix_affichage;
                    do{
                        printf("\n                     votre choix est :");
                        scanf("%d",&choix_affichage);
                        getchar();
                        fflush(stdin);
                        if(choix_affichage!=2 && choix_affichage!=1){
                            system("powershell -c (New-Object Media.SoundPlayer 'reponse_fausse.wav').PlaySync();");
                        }
                    }while(choix_affichage!=2 && choix_affichage!=1);
                    if(choix_affichage==1){
                        printf("la liste des plus long mots est :\n");
                        for(int i=0;i<l1;i++){
                            printf("              -%s\n",combinaison_max[i]);
                        }
                    }
                    else{
                        if(choix_affichage==2){
                            printf("la liste des mots possibles est :\n");
                                for(int i=0;i<l;i++){
                                    printf("              -%s\n",combinaison[i]);
                                }
                        }
                    }
                     do{
                        printf("voulez vous continuez : \n");
                        printf("     tapez (o/O)pour continuer ou (n/N)pour terminer");
                        scanf("%c",&choix);
                     }while(toupper(choix)!='N' && toupper(choix)!='O');
                     nb_manche++;
                }while(toupper(choix)!='N');
                printf("       \nla table des scores est comme suit\n\n");
                printf("\033[35m            joueur 1                   joueur 2\033[0m\n\n");
                printf("-------------------------------------------------\n\n");
                int score1,score2;
                score1=0;
                score2=0;
                for(int ligne=0;ligne<nb_manche-1;ligne++){
                    score1=score1+manche[ligne][0];
                    score2=score2+manche[ligne][1];
                    printf("\033[34m                   score manche n %d\033[0m\n",ligne+1);
                    printf("----------------------------------------------\n\n");
                    printf("               %d                     %d\n\n",manche[ligne][0],manche[ligne][1]);
                    printf("----------------------------------------------\n\n");

                }
                printf("\033[33mle final est    %d                      %d\033[0m\n\n",score1,score2);
                if(score1>score2){
                    printf("\033[33m-------------------------le joueur 1 est le gagnant\033[0m\n\n\n");
                }
                else{
                    if(score2>score1){
                        printf("\033[33m------------------------le joueur 2 est le gagnant\033[0m\n\n\n");
                    }
                    if(score1==score2){
                        printf("\033[34m-----------------------------egalite\033[0m\n\n\n");
                    }
                }
            }
            if(choix==0){
                system("cls");
                printf("\n\033[0;34m                  vous avez quittee le jeux\033[0m");
                system("powershell -c (New-Object Media.SoundPlayer 'aurevoir.wav').PlaySync();");
                return 0;
            }
        }
    }while(choix!=0);

}
